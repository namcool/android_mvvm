package com.example.architectureexample;

import androidx.appcompat.app.AppCompatActivity;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private NoteViewModel noteViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        noteViewModel = ViewModelProviders.of(this).get(NoteViewModel.class);
    }
}